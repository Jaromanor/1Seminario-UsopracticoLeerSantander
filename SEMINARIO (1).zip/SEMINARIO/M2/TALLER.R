library(readxl)
library(dplyr)
library(tidyr)
library(writexl)
library(lubridate)
library(xlsx)

# SELECCIÓN DE ESTUDIANTES

base1<-read_xlsx("Baseabri2021.xlsx")
summary(base1)
str(base1)

base1<-filter(base1,ESTADO=="MATRICULADO")
base1<-filter(base1,SECTOR=="OFICIAL")
base2<-filter(base1,GRADO_COD>=4 & GRADO_COD<=10,ZONA_SEDE=="RURAL")

group_by(base2,DANE) #236 IE

grado10urbanos<-filter(base1,GRADO_COD==10 & ZONA_SEDE=="URBANA")

base3<-bind_rows(base2,grado10urbanos)
group_by(base3,DANE)

#ADECUAR BASE DE DATOS CON CRITERIOS DE SOPORTE TÉCNICO Y DIRECTIVOS

##Criterios de Directivos

###Elimino columnas o variables que no necesito
base4<-select(base3,-c(1,6,12,13,14,22,23,24))
summary(base4)
###Crear nuevas variables

####Variable Provincia
provincias<-read_xlsx("provincia-municipio.xlsx")
base4<-rename(base4,MUNICIPIO=JERARQUIA)



base5<-left_join(provincias,base4,by="MUNICIPIO") 
summary(base5) #Mostrar prooblema y evidenciar la importancia de estandarizar


base4$MUNICIPIO[base4$MUNICIPIO=="GAMBITA"]<-"GÁMBITA"
base4$MUNICIPIO[base4$MUNICIPIO=="LEBRÍJA"]<-"LEBRIJA"

#Si fuera factores levels(base4$MUNICIPIO)[levels(base4$MUNICIPIO)=="GAMBITA"]<-"GÁMBITA"

base5<-left_join(provincias,base4,by="MUNICIPIO")
summary(base5)

filter(base5,is.na(GRADO_COD))

base5<-right_join(provincias,base4,by="MUNICIPIO")
summary(base5)


####Variable Edad

base5$FECHA_NACIMIENTO<-as.Date(base5$FECHA_NACIMIENTO)

base5<-mutate(base5,
              EDAD=floor(time_length(ymd(Sys.Date())-ymd(base5$FECHA_NACIMIENTO),
                                     unit="year")))


####Ordenar la Data

base6<-select(base5,c(2,1,4,3,6,7,5,8,9,10,18,11,12:17,19))


## Criterios Soporte Técnico

###Seleccionar variables
soporte<-select(base6,-c(3,7,18))

###Dejar nombre en un solo campo

soporte<-unite(soporte,NOMBRES,c(13,14,11,12),sep = " ")

###Cambiar Nombres de variables

soporte<-rename(soporte,
                COLEGIO=INSTITUCION,
                GRADOS=GRADO_COD,CURSO=GRUPO,SEXO=GENERO,
                DOCUMENTO=DOC_1)
summary(soporte)

###Cambiar registro de SEXO: masculino 0, femenino 1


soporte$SEXO[soporte$SEXO=="MASCULINO"]<-0
soporte$SEXO[soporte$SEXO=="FEMENINO"]<-1

#nota DESDE PRINCIPIOS SE DEBIÓ CAMBIAR EL TIPO CARACTER POR FACTOR

base7<-mutate_at(base6,vars(1,2,4,5:10,12:17),as.factor)
summary(base7)

soporte1<-mutate_at(soporte,vars(1:8,10,11),as.factor)
summary(soporte1)


#GENERAR LISTAS DE ESTUDIANTES REGISTRADOS POR INSTITUCIÓN EDUCATIVA PARA LOS
#RECTORES Y DOCENTES ELEGIDOS

write_xlsx(base7,"registrados.xlsx")

summary(base7)

base7$DANE<-as.factor(base7$DANE)
datas1 <- split(base7,base7$DANE)
DANE <- levels(base7$DANE)

for (i in seq_along(datas1)){
  coleg<-paste(DANE[i],".xlsx",collapse="")
  write.xlsx(datas1[[i]], ##Escoja únicamente el elemento de la lista
             file = coleg)
}

#Qué alternativas tenemos para que el nombre salga?

#INCLUIR LOS DEMÁS ESTUDIANTES


base2restantes<-filter(base1,GRADO_COD>=4 & GRADO_COD <=10)
numdoc<-base7$DOC_1
length(numdoc)

base8<-filter(base2restantes, !DOC_1 %in% numdoc) #%in% verificar la presencia de elementos en un vector o una lista



#################################
#################################

##Criterios de Directivos

###Base total

basetotal<-base2restantes

###Elimino columnas o variables que no necesito
basetotal<-select(basetotal,-c(1,6,12,13,14,22,23,24))
summary(basetotal)
###Crear nuevas variables

####Variable Provincia
provincias<-read_xlsx("provincia-municipio.xlsx")
basetotal<-rename(basetotal,MUNICIPIO=JERARQUIA)


basetotal$MUNICIPIO[basetotal$MUNICIPIO=="GAMBITA"]<-"GÁMBITA"
basetotal$MUNICIPIO[basetotal$MUNICIPIO=="LEBRÍJA"]<-"LEBRIJA"

#Si fuera factores levels(base4$MUNICIPIO)[levels(base4$MUNICIPIO)=="GAMBITA"]<-"GÁMBITA"


basetotal1<-right_join(provincias,basetotal,by="MUNICIPIO")
summary(basetotal1)


####Variable Edad

basetotal1$FECHA_NACIMIENTO<-as.Date(basetotal1$FECHA_NACIMIENTO)

basetotal1<-mutate(basetotal1,
              EDAD=floor(time_length(ymd(Sys.Date())-ymd(basetotal1$FECHA_NACIMIENTO),
                                     unit="year")))


####Ordenar la Data

basetotal1<-select(basetotal1,c(2,1,4,3,6,7,5,8,9,10,18,11,12:17,19))


## Criterios Soporte Técnico

###Seleccionar variables
soportetotal<-select(basetotal1,-c(3,7,18))

###Dejar nombre en un solo campo

soportetotal<-unite(soportetotal,NOMBRES,c(13,14,11,12),sep = " ")

###Cambiar Nombres de variables

soportetotal<-rename(soportetotal,
                COLEGIO=INSTITUCION,
                GRADOS=GRADO_COD,CURSO=GRUPO,SEXO=GENERO,
                DOCUMENTO=DOC_1)
summary(soportetotal)

###Cambiar registro de SEXO: masculino 0, femenino 1


soportetotal$SEXO[soportetotal$SEXO=="MASCULINO"]<-0
soportetotal$SEXO[soportetotal$SEXO=="FEMENINO"]<-1

#nota DESDE PRINCIPIOS SE DEBIÓ CAMBIAR EL TIPO CARACTER POR FACTOR

basetotal1<-mutate_at(basetotal1,vars(1,2,4,5:10,12:17),as.factor)
summary(basetotal1)

soportetotal<-mutate_at(soportetotal,vars(1:8,10,11),as.factor)
summary(basetotal1)


##########################################################
##########################################################

#CAMBIO DE AÑO

## ADECUAR BASE DEL SIMAT DEL 25 DE FEBRERO

simatfeb25<-filter(feb20221,
                   ESTADO=="MATRICULADO",SECTOR=="OFICIAL",
                   GRADO_COD>=4)

## Escoger solamente los que no están registrados

DOC2021<-basetotal1$DOC_1

simatfeb25_1<-filter(simatfeb25, !DOC_1 %in% DOC2021)

## Adecuar esos nuevos estudiantes con los criterios y unirlas

#################################

###Criterios de Directivos

####Elimino columnas o variables que no necesito
simatfeb25_1<-select(simatfeb25_1,-c(1,6,12,20,21))
summary(simatfeb25_1)
###Crear nuevas variables

####Variable Provincia
provincias<-read_xlsx("provincia-municipio.xlsx")
simatfeb25_1<-rename(simatfeb25_1,MUNICIPIO=JERARQUIA)


simatfeb25_1$MUNICIPIO[simatfeb25_1$MUNICIPIO=="GAMBITA"]<-"GÁMBITA"
simatfeb25_1$MUNICIPIO[simatfeb25_1$MUNICIPIO=="LEBRÍJA"]<-"LEBRIJA"

#Si fuera factores levels(base4$MUNICIPIO)[levels(base4$MUNICIPIO)=="GAMBITA"]<-"GÁMBITA"


simatfeb25_1<-right_join(provincias,simatfeb25_1,by="MUNICIPIO")
summary(simatfeb25_1)


####Variable Edad

simatfeb25_1$FECHA_NACIMIENTO<-as.Date(simatfeb25_1$FECHA_NACIMIENTO)

simatfeb25_1<-mutate(simatfeb25_1,
                   EDAD=floor(time_length(ymd(Sys.Date())-ymd(simatfeb25_1$FECHA_NACIMIENTO),
                                          unit="year")))


####Ordenar la Data

simatfeb25_1<-select(simatfeb25_1,c(2,1,4,3,6,7,5,8,9,10,18,11,12:17,19))


## Criterios Soporte Técnico

###Seleccionar variables
soportesimatfeb25_1<-select(simatfeb25_1,-c(3,7,18))

###Dejar nombre en un solo campo

soportesimatfeb25_1<-unite(soportesimatfeb25_1,NOMBRES,c(13,14,11,12),sep = " ")

###Cambiar Nombres de variables

soportesimatfeb25_1<-rename(soportesimatfeb25_1,
                     COLEGIO=INSTITUCION,
                     GRADOS=GRADO_COD,CURSO=GRUPO,SEXO=GENERO,
                     DOCUMENTO=DOC_1)
summary(soportesimatfeb25_1)

###Cambiar registro de SEXO: masculino 0, femenino 1


soportesimatfeb25_1$SEXO[soportesimatfeb25_1$SEXO=="MASCULINO"]<-0
soportesimatfeb25_1$SEXO[soportesimatfeb25_1$SEXO=="FEMENINO"]<-1

#nota DESDE PRINCIPIOS SE DEBIÓ CAMBIAR EL TIPO CARACTER POR FACTOR

simatfeb25_1<-mutate_at(simatfeb25_1,vars(1,2,4,5:10,12:17),as.factor)
summary(simatfeb25_1)

soportesimatfeb25_1<-mutate_at(soportesimatfeb25_1,vars(1:8,10,11),as.factor)
summary(soportesimatfeb25_1)


##########################################################

#Unir bases para tener consolidados totales


totalfeb<-bind_rows(basetotal1,simatfeb25_1)
soportotalfeb<-bind_rows(soportetotal,soportesimatfeb25_1)


#USABILIDAD

#Escoger Matriculados con datos del SIMAT de Julio

basejul<-read_xlsx("Basejul2022.xlsx")
basejul1<-filter(basejul,ESTADO=="MATRICULADO",SECTOR=="OFICIAL")

docID<-basejul1$DOC_1

usabilidad_matriculados<-filter(usabilidad, ID_1 %in% docID)

#Escoger No Matriculados

usabilidad_NO_matriculados<-filter(usabilidad, !ID_1 %in% docID)

#Segmentar No Matriculados entre sin y con avance

usab_no_matri_no_avance<-filter(usabilidad_NO_matriculados,AVANCE=="0.00%")
usab_no_matri_SI_avance<-filter(usabilidad_NO_matriculados,AVANCE!="0.00%")


#Crear Dataframe con variables de Interés para concurso: TALLER
















