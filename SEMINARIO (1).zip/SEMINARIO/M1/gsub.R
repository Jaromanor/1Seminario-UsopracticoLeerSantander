df <- data.frame(
  municipios = c("Bucaramanga", "Girón", "Floridablanca", "Giron", "Barrancabermeja")
)
categorias_unicas <- unique(df$municipios)
num_categorias <- length(categorias_unicas)
df$municipios <- gsub("Giron", "Girón", df$municipios, fixed = TRUE)

?gsub


